from sqlite3 import Timestamp
from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func
import datetime

a_datetime = datetime.datetime.now()
datetime_without_microseconds = a_datetime.replace(microsecond = 0)

class Entry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    usn = db.Column(db.String(10), db.ForeignKey('user.id'))
    reason = db.Column(db.String(100))
    entry = db.Column(db.DateTime, default=datetime_without_microseconds)
    status = db.Column(db.String(10))

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key = True)
    password = db.Column(db.String(20))
    name = db.Column(db.String(50))
    mob = db.Column(db.Integer)
    block = db.Column(db.String(2))
    room = db.Column(db.String(5))
    emer = db.Column(db.String(20))
    utype = db.Column(db.String(20))
    entry = db.relationship('Entry')