function delete_Entry(entId) {
    fetch("/delete-entry", {
      method: "POST",
      body: JSON.stringify({ entId: entId }),
    }).then((_res) => {
      window.location.href = "/";
    });
  }
  