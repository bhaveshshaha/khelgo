from flask import Blueprint, render_template, request, flash, jsonify
from flask_login import login_required, current_user
from .models import Entry, User
from sqlalchemy import update
from . import db

views = Blueprint('views', __name__)

@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    entry = Entry.query.all()
    stud = User.query.all()
    if request.method == 'POST':
        # if request.form['submit_button'] == 'Allow':
        #     flash('Accepted', category = 'success')
        # if request.form['submit_button'] == 'Decline':
        #     flash('Rejected', category = 'error')

        if request.form['submit_button'] == 'Submit Request':
            ent = request.form.get('note')
            if len(ent) < 2:
                flash('Select an option', category = 'error')
            else:
                new_ent = Entry(reason = ent, usn = current_user.id, status = 'ACTIVE')
                db.session.add(new_ent)
                db.session.commit()
                flash('Note added!', category = 'success')
    return render_template('home.html', user = current_user, entry = entry, stud = stud)

@views.route('/details')
@login_required
def details():
    return render_template('details.html', user = current_user)

@views.route('/requests')
@login_required
def requests():
    entry = Entry.query.all()
    users = User.query.all()
    return render_template('requests.html', user = current_user, entry = entry, users = users)

@views.route('/delete-entry', methods=['POST'])
def delete_Entry():
    Entry = json.loads(request.data)
    EntryId = Entry['entryId']
    Entry = Entry.query.get(EntryId)
    if Entry:
        if Entry.user_id == current_user.id:
            db.session.delete(Entry)
            db.session.commit()

    return jsonify({})

@views.route('/secact/<int:id>')
@login_required
def secact(id):
    entry = Entry.query.get_or_404(id)
    db.session.query(Entry).filter(Entry.id == id).update({ 'status' : 'ACCEPTED' })
    db.session.commit()
    entry = Entry.query.all()
    stud = User.query.all()
    return render_template('home.html', user = current_user, entry = entry, stud = stud)

@views.route('/secrej/<int:id>')
@login_required
def secrej(id):
    entry = Entry.query.get_or_404(id)
    db.session.query(Entry).filter(Entry.id == id).update({ 'status' : 'REJECTED' })
    db.session.commit()
    entry = Entry.query.all()
    stud = User.query.all()
    return render_template('home.html', user = current_user, entry = entry, stud = stud)